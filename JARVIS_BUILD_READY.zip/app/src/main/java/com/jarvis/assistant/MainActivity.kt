package com.jarvis.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.provider.AlarmClock
import android.speech.*
import android.speech.tts.TextToSpeech
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder
import java.util.Locale

enum class JarvisState { IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, ERROR }

data class CommandIntent(
    val action: String,
    val target: String? = null,
    val query: String? = null,
    val requiresConfirmation: Boolean = false
)

class AppResolver(private val context: Context) {
    private val aliases = mapOf(
        "youtube" to "com.google.android.youtube",
        "yt" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android",
        "spotify" to "com.spotify.music",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "play store" to "com.android.vending",
        "google play" to "com.android.vending"
    )

    fun resolve(name: String): String? {
        val pkg = aliases[name.trim().lowercase()] ?: return null
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            pkg
        } catch (_: Exception) { null }
    }
}

class ActionRouter(private val context: Context) {
    private val resolver = AppResolver(context)

    fun execute(i: CommandIntent): String {
        return try {
            when (i.action) {
                "OPEN_APP" -> {
                    val pkg = resolver.resolve(i.target ?: "")
                    if (pkg == null) return "I couldn't find ${i.target} installed."
                    val launch = context.packageManager.getLaunchIntentForPackage(pkg)
                        ?: return "I couldn't open ${i.target}."
                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "${i.target} opened"
                }
                "SEARCH_WEB" -> {
                    val q = URLEncoder.encode(i.query ?: "", "UTF-8")
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    "Google Search opened"
                }
                "OPEN_WEBSITE" -> {
                    val raw = i.target ?: return "No website specified."
                    val url = if (raw.startsWith("http")) raw else "https://$raw"
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Website opened"
                }
                "OPEN_PLAY_STORE", "SEARCH_PLAY_STORE" -> {
                    val query = i.query ?: ""
                    val uri = if (query.isBlank()) Uri.parse("market://details?id=com.android.vending")
                    else Uri.parse("market://search?q=${URLEncoder.encode(query, "UTF-8")}")
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        context.startActivity(Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/search?q=${URLEncoder.encode(query, "UTF-8")}&c=apps")
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    "Play Store opened"
                }
                "OPEN_MAPS", "SEARCH_MAPS" -> {
                    val q = i.query ?: ""
                    val uri = if (q.isBlank()) Uri.parse("geo:0,0?q=")
                    else Uri.parse("geo:0,0?q=${URLEncoder.encode(q, "UTF-8")}")
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Maps opened"
                }
                "SET_TIMER" -> {
                    val seconds = Regex("(\\d+)").find(i.query ?: "")?.groupValues?.get(1)?.toIntOrNull()
                        ?: return "I couldn't understand the timer duration."
                    context.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, seconds * 60)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Timer opened"
                }
                "SET_ALARM" -> {
                    context.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Alarm")
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Alarm screen opened"
                }
                "OPEN_SETTINGS" -> {
                    context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Settings opened"
                }
                "OPEN_WIFI_SETTINGS" -> {
                    context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Wi-Fi settings opened"
                }
                "OPEN_BLUETOOTH_SETTINGS" -> {
                    context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Bluetooth settings opened"
                }
                "OPEN_CAMERA" -> {
                    context.startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Camera opened"
                }
                "OPEN_GALLERY" -> {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://media/internal/images/media"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Gallery opened"
                }
                "OPEN_CALCULATOR" -> {
                    val p = context.packageManager
                    val candidates = listOf("com.google.android.calculator", "com.android.calculator2")
                    val pkg = candidates.firstOrNull { runCatching { p.getPackageInfo(it, 0) }.isSuccess }
                    val launch = pkg?.let { p.getLaunchIntentForPackage(it) }
                        ?: return "I couldn't find a calculator app."
                    context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Calculator opened"
                }
                else -> "I can't perform that action on this device yet."
            }
        } catch (_: Exception) {
            "I couldn't perform that action."
        }
    }
}

class CommandParser {
    fun parse(text: String): CommandIntent? {
        val s = text.trim().lowercase(Locale.getDefault())
            .removePrefix("hey jarvis").trim()
            .removePrefix("hi jarvis").trim()
            .removePrefix("jarvis").trim()

        fun targetAfter(prefixes: List<String>): String? =
            prefixes.firstNotNullOfOrNull { p ->
                if (s.startsWith(p)) s.removePrefix(p).trim().takeIf { it.isNotBlank() } else null
            }

        targetAfter(listOf("open "))?.let { target ->
            return when {
                target == "play store" || target == "google play" -> CommandIntent("OPEN_PLAY_STORE")
                target == "maps" || target == "google maps" -> CommandIntent("OPEN_MAPS")
                target == "wifi settings" || target == "wi-fi settings" -> CommandIntent("OPEN_WIFI_SETTINGS")
                target == "bluetooth settings" -> CommandIntent("OPEN_BLUETOOTH_SETTINGS")
                target == "settings" -> CommandIntent("OPEN_SETTINGS")
                target == "camera" -> CommandIntent("OPEN_CAMERA")
                target == "gallery" || target == "photos" -> CommandIntent("OPEN_GALLERY")
                target == "calculator" -> CommandIntent("OPEN_CALCULATOR")
                target.contains(".") -> CommandIntent("OPEN_WEBSITE", target = target)
                else -> CommandIntent("OPEN_APP", target = target)
            }
        }

        if (s.contains("search") && (s.contains("google") || s.contains("web"))) {
            val q = s.replace(Regex(".*?(google|web)"), "")
                .replace(Regex("\b(search|for|on|pe|mein|में|करो|karo)\b"), " ")
                .trim()
            return CommandIntent("SEARCH_WEB", query = q)
        }

        if (s.contains("play store") && s.contains("search")) {
            val q = s.substringAfter("search").trim().replace(Regex("\bfor\b|\bmein\b|\bमें\b|\bकरो\b"), " ").trim()
            return CommandIntent("SEARCH_PLAY_STORE", query = q)
        }

        if (s.contains("set a timer") || s.contains("set timer") || s.contains("timer")) {
            return CommandIntent("SET_TIMER", query = s, requiresConfirmation = false)
        }

        if (s.contains("set an alarm") || s.contains("set alarm")) {
            return CommandIntent("SET_ALARM", requiresConfirmation = false)
        }

        if (s.contains("wifi settings") || s.contains("wi-fi settings"))
            return CommandIntent("OPEN_WIFI_SETTINGS")
        if (s.contains("bluetooth settings"))
            return CommandIntent("OPEN_BLUETOOTH_SETTINGS")
        if (s == "maps" || s == "google maps")
            return CommandIntent("OPEN_MAPS")

        return null
    }
}

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (!granted) speak("Microphone access is required for voice commands.") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { JarvisApp() }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun listen(onResult: (String) -> Unit, onState: (JarvisState) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { onState(JarvisState.LISTENING) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { onState(JarvisState.ERROR) }
                override fun onResults(b: Bundle?) {
                    val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text != null) onResult(text) else onState(JarvisState.ERROR)
                }
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        recognizer?.startListening(intent)
    }

    @Composable
    private fun JarvisApp() {
        var state by remember { mutableStateOf(JarvisState.IDLE) }
        var transcript by remember { mutableStateOf("") }
        val parser = remember { CommandParser() }
        val router = remember { ActionRouter(this@MainActivity) }
        val infinite = rememberInfiniteTransition(label = "orb")
        val pulse by infinite.animateFloat(
            initialValue = 0.94f, targetValue = 1.06f,
            animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse"
        )

        MaterialTheme(colorScheme = darkColorScheme()) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color(0xFF05070D)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxSize().padding(24.dp)
                ) {
                    Spacer(Modifier.height(45.dp))
                    Text("JARVIS", color = Color.White, fontSize = 28.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        when (state) {
                            JarvisState.IDLE -> "Ready when you are."
                            JarvisState.LISTENING -> "Listening…"
                            JarvisState.THINKING -> "Processing…"
                            JarvisState.EXECUTING -> "Executing…"
                            JarvisState.SPEAKING -> "Speaking…"
                            JarvisState.ERROR -> "Something went wrong."
                        },
                        color = Color(0xFF8BE9FF)
                    )

                    Spacer(Modifier.weight(1f))

                    Box(
                        modifier = Modifier.size(230.dp).scale(if (state == JarvisState.IDLE) pulse else 1f)
                            .background(Color(0xFF082A38), CircleShape)
                            .clickable {
                                state = JarvisState.LISTENING
                                listen(
                                    onResult = { text ->
                                        transcript = text
                                        state = JarvisState.THINKING
                                        val intent = parser.parse(text)
                                        if (intent == null) {
                                            state = JarvisState.SPEAKING
                                            speak("I couldn't understand that command.")
                                        } else if (intent.requiresConfirmation) {
                                            state = JarvisState.SPEAKING
                                            speak("Confirmation is required for that action.")
                                        } else {
                                            state = JarvisState.EXECUTING
                                            val result = router.execute(intent)
                                            speak(result)
                                            state = JarvisState.SPEAKING
                                        }
                                    },
                                    onState = { state = it }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("J", color = Color(0xFF75E6FF), fontSize = 72.sp)
                    }

                    Spacer(Modifier.weight(1f))

                    if (transcript.isNotBlank())
                        Text(transcript, color = Color.LightGray, fontSize = 16.sp)

                    Spacer(Modifier.height(24.dp))

                    Button(
                        onClick = {
                            state = JarvisState.LISTENING
                            listen(
                                onResult = { text ->
                                    transcript = text
                                    state = JarvisState.THINKING
                                    val intent = parser.parse(text)
                                    if (intent == null) {
                                        state = JarvisState.SPEAKING
                                        speak("I couldn't understand that command.")
                                    } else {
                                        state = JarvisState.EXECUTING
                                        val result = router.execute(intent)
                                        speak(result)
                                        state = JarvisState.SPEAKING
                                    }
                                },
                                onState = { state = it }
                            )
                        },
                        modifier = Modifier.size(190.dp, 58.dp)
                    ) {
                        Text("🎙  MIC", fontSize = 17.sp)
                    }

                    Spacer(Modifier.height(35.dp))
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
