# JARVIS Android

A native Kotlin + Jetpack Compose voice-first Android assistant starter.

## Build

Open this folder in Android Studio with Gradle/JDK compatible with Android Gradle Plugin 8.7.x.

Run:
./gradlew assembleDebug

Install:
app/build/outputs/apk/debug/app-debug.apk

## Current real functionality

- Android SpeechRecognizer
- Runtime microphone permission
- Text-to-Speech
- Allowlisted ActionRouter
- Dynamic common-app resolution
- YouTube/Chrome/WhatsApp/Spotify/Maps/Play Store launching
- Google web search
- Website opening
- Play Store search
- Maps intents
- Timer/alarm intents
- Wi-Fi/Bluetooth/settings navigation
- Camera/gallery/calculator launching
- Futuristic Compose UI

## Notes

Third-party apps and Android versions may restrict certain capabilities. The app never uses arbitrary shell commands or silent installation.

For production use, add a real AI CommandUnderstandingProvider and stronger confirmation/contact flows before enabling sensitive actions such as calls or messages.
